<?php
	include("Login.php");
?>
<html>
<head>
<LINK REL="SHORTCUT ICON" HREF="fb_files/fb_title_icon/Faceback.ico" />
	<style>
		#singup_button
		{
			background:#69A74E;
			color:#FFFFFF;
			border-top-color:#3B6E22;
			border-right-color:#2C5115;
			border-left-color:#3B6E22;
			font-size:15px;
			height:30;
			width:75;
			font-weight:bold;
			box-shadow:-5px 0px 10px 1px rgb(0,0,0);
		}
	</style>
     <link href="fb_files/fb_font/font.css" rel="stylesheet" type="text/css">
</head>
<body>

<div style="position:absolute;left:0%;top:0%; height:13.2%; width:100%; z-index:-1; background:#69a74e">   </div>
<div style="position:absolute;left:13.5%; top:3.3%; font-size:45; font-weight:900; color:#FFFFFF; font-weight:bold;"> <font face="myFbFont">  MyCircle </font> </div>




<div style="position:absolute;left:13.6%; top:14.8%;"> <a href="index.php" style="text-decoration:none;"> <input type="button" value="Sign Up" id="singup_button">    </a> </div>

</body>
</html>