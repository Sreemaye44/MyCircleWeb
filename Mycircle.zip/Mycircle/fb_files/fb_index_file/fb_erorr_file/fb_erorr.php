<html>
<head>
</head>
<body>

	<!-- erorr Designing -->
		
		<div id="error_design_format" style="display:none;">
		<div style="position:absolute;left:57.3%; top:90%; height:5%; width:29%; z-index:1; background:#FFEBE8; box-shadow:5px 0px 10px 1px rgb(150,0,0); ">   </div>
			<div style="position:absolute;left:57.2%; top:90%; height:1; width:29.1%; background-color:#DD3C10; z-index:1; "> </div>
			<div style="position:absolute;left:57.2%; top:90%; height:5.1%; width:0.08%; background-color:#DD3C10; z-index:1; "> </div>
			<div style="position:absolute;left:57.2%; top:95%; height:1; width:29.1%; background-color:#DD3C10; z-index:1; "> </div>
			<div style="position:absolute;left:86.3%; top:90%; height:5.1%; width:0.08%; background-color:#DD3C10; z-index:1; "> </div>
		</div>
		
		
		<div id="blank_error" style="display:none; position:absolute; left:65%; top:90.7%; z-index:1"> You must fill in all of the fields. </div>
		<div id="Name_error" style="display:none; position:absolute; left:63.5%; top:90.7%; z-index:1"> The name contains invalid characters. </div>
		<div id="full_Name_error" style="display:none; position:absolute; left:64.9%; top:90.7%; z-index:1"> You must provide your full name. </div>
		<div id="Email_error" style="display:none; position:absolute; left:64.9%; top:90.7%; z-index:1"> Please enter a valid email address. </div>
		<div id="Email_not_match_error" style="display:none; position:absolute; left:61%; top:90.7%; z-index:1"> Your emails do not match. Please try again. </div>
		<div id="Password_error" style="display:none; position:absolute; left:60%; top:91%; z-index:1;"> Your password must be at least 6 characters long. </div>
		<div id="Gender_error" style="display:none; position:absolute; left:64%; top:90.7%; z-index:1"> Please select either Male or Female. </div>
		<div id="Date_error" style="display:none; position:absolute; left:62%; top:90.7%; z-index:1"> You must indicate your full birthday to register. </div>
		
		
</body>
</html>